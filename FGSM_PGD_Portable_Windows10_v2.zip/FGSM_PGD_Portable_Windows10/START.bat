@echo off
if not exist "%~dp0index.html" (
  echo ERROR: index.html not found next to START.bat.
  echo Extract the whole ZIP first ^(right-click - Extract All^), then run START.bat again.
  pause
  exit /b 1
)
start "" "%~dp0index.html"
